# Script to download git and the git repository
# Conor Murphy

#Code to install git
sudo yum install git -y

#Code to download git repository
git clone https://github.com/x-Dash-x/cloud_ca.git

#You now have downloaded the Git Repository 